user_pref("mailnews.start_page.enabled", false);
